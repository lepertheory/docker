#!/usr/bin/env python
from lzma import *
from warnings import warn
warn("'liblzma' has been renamed to 'lzma'!\n Please update code to import 'lzma'!", DeprecationWarning, stacklevel=1)
